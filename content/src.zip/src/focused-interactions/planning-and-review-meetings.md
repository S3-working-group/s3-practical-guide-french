## Réunions de planification et d'évaluation

<summary>
<strong>Les gens se rencontrent à intervalles réguliers (1-4 semaines) lors de réunions timeboxées pour planifier et évaluer le travail.</strong>
</summary>

**Réunion de planification** : sélectionnez et estimez les éléments de travail pour la prochaine itération.

**Réunion d'évaluation** : examinez les éléments de travail terminés et décidez quels changements apporter pour la prochaine itération.

![Réunions de planification et d'évaluation](img/meetings/planning-review.png)