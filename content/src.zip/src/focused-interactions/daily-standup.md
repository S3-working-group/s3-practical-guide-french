## Point quotidien

<summary>
<strong>Réunissez-vous chaque jour pour coordonner le travail, faciliter l'apprentissage, améliorer votre productivité et votre efficacité.</strong>
</summary>

- [timeboxé](glossary:timebox) (habituellement 15 minutes)
- chaque jour à la même heure
- l'équipe se réunit autour d'un tableau/outil de gestion de projet visible pour : 
    - organiser le travail quotidien
    - adresser les obstacles/freins
    - adapter les [ententes](glossary:agreement) existantes ou en créer de nouvelles sur-le-champ

![Le point quotidien est une réunion essentielle pour les équipes auto-organisées.](img/meetings/planning-review-standup.png)