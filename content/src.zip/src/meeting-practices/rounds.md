## Tours de table

<summary>
<strong>Lors d'une réunion de groupe, donnez la parole à chacun son tour.</strong>
</summary>

Les tours de table sont une technique de facilitation de groupe pour maintenir l'équivalence et soutenir un dialogue efficace.

Soyez clairs sur la finalité et le résultat attendu de chaque tour de table.

Asseyez-vous en cercle, commencez chaque tour de table par une personne différente, et changez le sens de rotation (horaire ou anti-horaire) pour faire varier qui parle en premier et dernier ainsi que l'ordre des contributions.

![Tours de table](img/circle/rounds.png)