## Backlog (panier) de gouvernance

<summary>
{{define:governance-backlog}}
</summary>

Un backlog (panier) de gouvernance contient :

- des questions nécessitant une décision
- des propositions à créer et considérer
- la sélection de candidats pour des rôles

**Note:** Les compte-rendus à venir et les ententes à revoir sont généralement ajoutés directement à l'ordre du jour, plutôt que dans le backlog (panier).