## Cercle de service

<summary>
<strong>Externalisez les services requis par deux domaines ou plus.</strong>
</summary>

Un cercle de service peut être constitué par des membres des [domaines](glossary:domain) qu'ils servent, et/ou par d'autres personnes aussi.

![Cercle de service](img/structural-patterns/service-circle.png)