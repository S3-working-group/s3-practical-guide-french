## Demander un soutien

<summary>
<strong>Un protocole simple pour apprendre, partager ses compétences et établir des liens, en respectant les tâches et attributions de chacun.</strong>
</summary>

Demandez à quelqu'un : "*voudrais-tu bien m'aider sur... *?" La personne accepte ou décline avec un simple "*oui*" ou "*non*".

- si la requête est déclinée, la personne qui demande accepte cette réponse sans négocier ou demander pourquoi
- si la requête n'est pas claire, demandez plus d'informations
- si vous acceptez une demande d'aide, soutenez votre pair au mieux de vos capacités