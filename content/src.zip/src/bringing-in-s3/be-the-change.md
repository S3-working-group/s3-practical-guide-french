## Incarner le changement

<summary>
<strong>Menez par l'exemple.</strong>
</summary>

Comportez-vous et agissez de la façon dont vous voudriez que les autres le fassent.