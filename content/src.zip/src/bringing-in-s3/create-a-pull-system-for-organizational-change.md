## Changements organisationnels par flux tirés

<summary>
<strong>Créez un environnement qui invite les membres d'une organisation à mener des changements.</strong>
</summary>

Changez les choses lorsqu'il y a un intérêt à le faire :

- Introduisez les pratiques permettant de surmonter les problèmes importants du moment.
- Ne cassez pas ce qui fonctionne déjà !
- Allez à la rencontre des gens…
- …et laissez-les choisir leur propre rythme.