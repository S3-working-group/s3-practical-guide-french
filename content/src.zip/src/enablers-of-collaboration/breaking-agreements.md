## Enfreindre les ententes

Enfreindre les [ententes](glossary:agreement) est parfois **nécessaire** mais peut **nuire** à la communauté.

Soyez responsable :

- **remédiez aux** perturbations engendrées
- **faites le point** le plus tôt possible avec les personnes impactées
- **modifiez l'entente** au lieu de l'enfreindre à plusieurs reprises