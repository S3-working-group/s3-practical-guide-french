## Adopter les sept principes

<summary>
<strong>Respectez les Sept Principes dans vos collaborations.</strong>
</summary>

L'adoption des sept principes réduit le nombre d'ententes explicites requises et guide l'adaptation des pratiques S3 au contexte particulier de l'organisation.

Les valeurs d'une organisation doivent supporter les sept principes.

![Les sept principes](img/framework/s3-principles-plain.png)

![Les valeurs d'une organisation doivent supporter les sept principes](img/collaboration-values/values-7principles.png)