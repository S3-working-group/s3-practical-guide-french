## Statuts et règlements

<summary>
Intégrez les principes et pratiques S3 dans vos statuts et règlements pour protéger <strong>l'intégrité légale</strong> et la <strong>culture organisationnelle</strong>
</summary>

Consignez :

- le consentement et l'équivalence pour la prise de décision
- le processus de sélection pour les rôles de leadership
- la structure organisationnelle, les [valeurs](glossary:values) et les [principes](glossary:principle)
- l'influence des propriétaires ou actionnaires
- le partage des gains et des coûts