## Clarifier le résultat attendu

<summary>
<strong>Explicitez les résultats attendus des ententes passées, des activités, des projets et des stratégies.</strong>
</summary>

Se mettre d'accord et consigner une description concise des résultats attendus.

Le résultat attendu peut être utilisé pour définir les [critères d'évaluation](section:evaluation-criteria) et les indicateurs (mesurés) pour évaluer les résultats effectivement obtenus.

![Résultats attendus, et critères d'évaluation](img/templates/outcome-and-criteria.png)