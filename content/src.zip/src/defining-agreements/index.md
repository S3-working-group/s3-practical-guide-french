### S3 promeut une approche fondée sur l'hypothèse pour les prises de décision

![Toute entente ou décision peut être considérée comme une expérimentation.](img/evolution/experiments.png)

![Le cycle de vie d'une entente](img/evolution/agreement-lifecycle-long.png)