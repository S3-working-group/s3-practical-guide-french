## Représentant

<summary>
<strong>Sélectionnez un membre de l'équipe pour participer aux décisions de gouvernance d'une autre équipe pour activer le flux d'informations et d'influence.</strong>
</summary>

Les représentants (c.à.d liens):

- défendent les intérêts d'une [équipe](glossary:team) dans une autre
- sont élus pour une durée limitée
- participent aux **décisions de gouvernance** de l'équipe avec laquelle ils sont reliés, et peuvent : 
    - porter des points à l'ordre du jour
    - participer à l'élaboration des propositions
    - lever des [objections](glossary:objection) aux propositions et aux [ententes](glossary:agreement) existantes