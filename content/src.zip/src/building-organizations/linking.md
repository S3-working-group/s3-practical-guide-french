## Lien

<summary>
<strong>Activez un flux d’information et d’influence entre deux équipes.</strong>
</summary>

Une équipe sélectionne l'un de ses membres pour représenter ses intérêts dans les décisions de [gouvernance](glossary:governance) d'une autre équipe.

![Un cercle lié à un autre cercle](img/structural-patterns/link.png)