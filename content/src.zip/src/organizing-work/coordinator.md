## Coordinateur

<summary>
Une personne remplissant le rôle de coordinateur est redevable de <strong>la coordination des opérations d'un domaine</strong> et est <strong>sélectionnée pour un mandat limité.</strong>
</summary>

Le coordinateur peut être sélectionné par l'équipe elle-même, ou par le [délégant](glossary:delegator).

Plusieurs coordinateurs peuvent collaborer pour synchroniser le travail au travers de plusieurs [domaines](glossary:domain).

Au lieu de choisir un coordinateur, une équipe peut choisir de s'auto-organiser.