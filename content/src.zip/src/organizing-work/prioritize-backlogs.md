## Prioriser les backlogs (paniers)

<summary>
<strong>Triez tous les éléments de travail inachevés en partant des plus importants, puis dépilez par le haut lorsqu'il y a une nouvelle capacité.</strong>
</summary>

Il ne peut y avoir deux éléments de même importance, ce qui signifie qu'il est nécessaire de s'entendre sur les priorités et faire des choix difficiles.

Un [backlog (panier)](glossary:backlog) priorisé aide à **rester concentré** sur les éléments les plus importants.