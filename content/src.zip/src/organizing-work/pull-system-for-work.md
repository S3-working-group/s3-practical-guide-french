## Travail en flux tiré

<summary>
<strong>Les personnes tirent de nouveaux éléments de travail lorsqu'elles ont la capacité de les traiter (au lieu que travail ne leur soit poussé ou affecté).</strong>
</summary>

Priorisez les éléments de travail pour assurer que les éléments importants soient traités en premier.

Tirer le travail évite de surcharger le système, en particulier lorsque le [travail en cours (WIP) par personne ou par équipe est limité](section:limit-work-in-progress).