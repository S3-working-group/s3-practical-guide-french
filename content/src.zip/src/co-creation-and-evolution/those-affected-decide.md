## Les personnes impactées décident

<summary>
<strong>Impliquez les gens dans les décisions qui les concernent, pour maintenir équivalence et redevabilité, et pour augmenter la quantité d'informations disponibles sur le sujet.</strong>
</summary>

Pour de plus grands groupes :

- facilitez le processus en plusieurs étapes et créez des sous-groupes, qui sélectionneront des délégués
- utilisez un outil en ligne et mener un processus asynchrone, [timeboxé](section:timebox-activities) et par étapes

Pensez également à inclure les personnes impactées dans l'évaluation et l'évolution des décisions.