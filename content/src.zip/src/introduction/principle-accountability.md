#### Le Principe de Redevabilité

*{{glossary:accountability}}*

Agir dans le cadre des ententes régissant les domaines dont vous êtes redevables, y compris l'organisation elle-même, les équipes dont vous faites partie et les rôles que vous portez.

Chaque membre de l'organisation est redevable de répondre efficacement aux intentions organisationnelles, en faisant le travail et/ou en assurant (soutenant) une collaboration efficace.

Les individus sont également redevables de leur travail, de leur apprentissage et de leur développement, et de se soutenir mutuellement.

Tout le monde dans une organisation est redevable d'aligner ses activités avec les valeurs organisationnelles.
