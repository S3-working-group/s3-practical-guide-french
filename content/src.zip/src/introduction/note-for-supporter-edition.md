
Merci d'avoir acheté l'édition supporter de ce livre. Nous espérons que vous l'apprécierez et qu'elle vous sera utile pour construire le type d'organisation dont vous voulez faire partie.

Tout le contenu de ce livre est disponible sous licence Creative Commons dans plusieurs langues et formats. Visitez notre site web sur [sociocracy30.org/practical-guide](https://sociocracy30.org/practical-guide) pour lire la version en ligne en plusieurs langues, ou téléchargez ce livre et d'autres ressources gratuites sur [sociocracy30.org/resources](https://sociocracy30.org/resources).