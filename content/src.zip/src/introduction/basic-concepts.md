## Les concepts de base

Avant d'aller plus loin, prenez le temps de vous familiariser avec des concepts de base derrière la S3 :

- Qu'est-ce qu'une pratique ?
- Les sept principes
- Comprendre les organisations : 
    - Intentions, valeur et gaspillage
    - Domaines, délégation et redevabilité
    - Gouvernance et opérations

Si vous ne comprenez pas l'un de ces termes, consultez notre glossaire à la fin.