## Liens

La **dernière version en ligne** du Guide Pratique située à <http://patterns.sociocracy30.org> peut être annotée via hypothes.is et est accompagnée d'un index alphabétique et d'une cartographie des pratiques pour une navigation facilitée.

Divers autres formats et langues du guide pratique peuvent être trouvés à <http://sociocracy30.org/guide/>

**Plus de ressources S3:** <http://sociocracy30.org/resources/>

**Site principal S3:** <http://sociocracy30.org>

**Suivez-nous sur twitter:** *@sociocracy30*