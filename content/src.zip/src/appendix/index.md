# Annexe

- Historique des modifications
- Liens
- Licence
- Auteurs
- Glossaire
- Index des pratiques