# [fit] Sociocratie 3.0

![fit](img/framework/logo.png)

# Un guide pratique

#### James Priest, Bernhard Bockelbrink, Liliana David

#### <http://patterns.sociocracy30.org>